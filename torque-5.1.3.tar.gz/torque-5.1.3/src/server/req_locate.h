#include "license_pbs.h" /* See here for the software license */
#ifndef _REQ_LOCATEJOB_H
#define _REQ_LOCATEJOB_H
#include "batch_request.h" /* batch_request */

int req_locatejob(struct batch_request *preq);

#endif /* _REQ_LOCATEJOB_H */
