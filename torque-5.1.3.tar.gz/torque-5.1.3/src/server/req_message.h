#ifndef _REQ_MESSAGE_H
#define _REQ_MESSAGE_H
#include "license_pbs.h" /* See here for the software license */

#include "batch_request.h" /* batch_request */

int req_messagejob(struct batch_request *preq);
  
/* static void post_message_req(struct work_task *pwt); */

#endif /* _REQ_MESSAGE_H */
