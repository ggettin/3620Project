#ifndef _REQ_MOVEJOB_H
#define _REQ_MOVEJOB_H
#include "license_pbs.h" /* See here for the software license */
#include "batch_request.h"

int req_movejob(struct batch_request *preq);

int req_orderjob(struct batch_request *preq);

#endif /* _REQ_MOVEJOB_H */
