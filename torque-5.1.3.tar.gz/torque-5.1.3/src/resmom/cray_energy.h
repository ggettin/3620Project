/*
 * cray_energy.h
 *
 *  Created on: May 2, 2014
 *      Author: bdaw
 */

#ifndef CRAY_ENERGY_H_
#define CRAY_ENERGY_H_

#include "license_pbs.h" /* See here for the software license */
#include "pbs_job.h"

void get_energy_used(job *pjob);



#endif /* CRAY_ENERGY_H_ */
